# install Logstash
## Ref https://www.elastic.co/guide/en/logstash/current/installing-logstash.html


install openjdk-8-jre-headless
### update
### install logstash
### Download and install the public signing key:
```
sudo rpm --import https://artifacts.elastic.co/GPG-KEY-elasticsearch
```
#### Add the following in your /etc/yum.repos.d/ directory in a file with a .repo suffix, for example logstash.repo
```
[logstash-8.x]
name=Elastic repository for 8.x packages
baseurl=https://artifacts.elastic.co/packages/8.x/yum
gpgcheck=1
gpgkey=https://artifacts.elastic.co/GPG-KEY-elasticsearch
enabled=1
autorefresh=1
type=rpm-md
```
### And your repository is ready for use. You can install it with:
```
sudo yum install logstash
```



*******************
Get data to practice

wget http://media.sundog-soft.com/es/access_log



### vi /etc/logstash/conf.d/logstash.conf
```
input {
        file {
                path => "/home/ec2-user/access_log"
                  start_posiiton => "beginning"
        }
}

filter {
        grok {
                match => { "message" => "%{COMBINEDAPACHELOG)" }
        }
        date {
                match => [ "timestamp", "dd/MMM/yyyy:HH:mm:ss Z" ]
        }
}

output {
        elasticsearch {
                hosts => ["localhost:9200"]
        }
        stdout {
                codec => rubydebug
        }
}
```

### Running Logstash
```
sudo systemctl start logstash.service
```
```
sudo systemctl status logstash.service
```  
##### Running Logstash with different config file
cd /usr/share/logstash
sudo bin/logstash -f /etc/logstash /conf.d/logstash.conf