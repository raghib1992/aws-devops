Install Java 10
https://www.oracle.com/java/technologies/java-archive-javase10-downloads.html

Install Elastic Search
https://www.elastic.co/downloads/elasticsearch
http://localhost:9200

Install Kibana
https://www.elastic.co/downloads/kibana


PORt allowed by server firewall
22 -SSH
9200 - ELastucsearch
-Kibana- 5601


if you want to edit elasticSearch Url, modify the same in kibana.yaml file