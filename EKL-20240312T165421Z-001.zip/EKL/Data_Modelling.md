# Parent_Child Relationship
curl -H "Content-Type: application/json" -XPUT '127.0.0.1:9200/series' -d '
{
        "mappings" : {
                "properties" : {
                        "film_to_franchise" : {
                            "type" : "join",
                            "relationship": {"franchise" : "film"}
                        }
                }
        }
}'



# dowlaoad data
wget http://media.sundog-soft.com/es8/series.json


# Enter the data
curl -H "Content-Type: application/json" -XPUT 127.0.0.1:9200/_bulk?pretty --data-binary @series.json

# Searchg quesry
curl -H "Content-Type: application/json" -XGET 127.0.0.1:9200/series/_search?pretty -d '
{
    "query" : {
        "has_parent" : {
            "parent_type" : "franchise",
            "query" : {
                "match" : {
                    "title" : "Star Wars"
                }
            }
        }
    }
}'

curl -H "Content-Type: application/json" -XGET 127.0.0.1:9200/series/_search?pretty -d '
{
    "query" : {
        "has_parent" : {
            "parent_type" : "film",
            "query" : {
                "match" : {
                    "title" : "Star Wars"
                }
            }
        }
    }
}'