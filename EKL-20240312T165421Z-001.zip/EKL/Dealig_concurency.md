# search doc eith index id
curl -XGET 127.0.0.1:9200/movies/_doc/109487?pretty


# update with checking seq no. and pri id
curl -H "Content-Type: application/json" -XPUT '127.0.0.1:9200/movies/_doc/109487?if_seq_no=5&if_primary_term=1' -d '
{
    "genre":
    ["IMAX","Sci-FI"],
    "title": "Intersteller",
    "year": 2014
}'



curl -H "Content-Type: application/json" -XPOST 127.0.0.1:9200/movies/_update/109487?retry_on_conflict=5 -d '
{
    "doc": {
        "title": "Intersteller typo"
    }
}'