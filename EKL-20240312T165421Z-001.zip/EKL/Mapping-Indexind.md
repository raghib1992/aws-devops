Dowanload data to put into es
http://media.sundog-soft.com/es/ml-latest-small.zip

Mapping:
Mapping is a schema defination es has reasonable defaults, but sometimes its need to customize them.

{
    "mappings": {
        "properties": {
            "year: {"type": "date"}
        }
    }
}

# Field type
string, byte, short, integer, long, float, double, boolean , date

# Field Index

Do you want this field indexed for full_text search? analyzed/ not_analyzed/ no

# Field ANalyzer
Define your token filter and tokenizer
1. standard (default) 
2. whitespace/ 
3. simple/ 
4. language/ 

## Chareacter Filter 
## Tokenizer
Split your string on whiteapace / punctuation non-letter

## Tokem Filter
lower casimg, stemming, synonyms, stopwords

******************************************************
1. Mapping
curl -H "Content-Type: application/json" -XPUT 127.0.0.1:9200/movies -d '
{
        "mappings" : {
                "properties" : {
                        "year" : {"type": "date" }
                }
        }
}'


2. Check mapping
curl -XGET 127.0.0.1:9200/movies/_mapping

3. Put some data into movies index
curl -H "Content-Type: application/json" -XPUT 127.0.0.1:9200/movies/_doc/109487?pretty -d '
{
    "genre":
    ["IMAX","Sci-FI"],
    "title": "Intersteller",
    "year": 2104
}'

4. search data
curl -XGET 127.0.0.1:9200/movies/_search?pretty

5. Insert data in bulk

 wget http://media.sundog-soft.com/es8/movies.json


curl -H "Content-Type: application/json" -XPUT 127.0.0.1:9200/_bulk?pretty --data-binary @movies.json


6. Update the doc

curl -H "Content-Type: application/json" -XPUT 127.0.0.1:9200/movies/_doc/109487?pretty -d '
{
    "genre":
    ["IMAX","Sci-FI"],
    "title": "Intersteller Foo",
    "year": 2104
}'


7. Get the index id
curl -XGET 127.0.0.1:9200/movies/_doc/109487?pretty



8. Delete data in ES
curl -XGET 127.0.0.1:9200/movies/_search?q=Dark
curl -XDELETE 127.0.0.1:9200/movies/_doc/58559