https://www.elastic.co/guide/en/kibana/current/install.html


https://www.elastic.co/guide/en/kibana/current/rpm.html




sudo vi /etc/kibana/kibana.yml
server.host: "0.0.0.0"


sudo /bin/systemctl daemon-reload
sudo /bin/systemctl enable kibana.service
sudo /bin/systemctl start kibana.service