sudo yum install java-1.8.0 -y

https://www.elastic.co/guide/en/elasticsearch/reference/current/rpm.html#install-rpm.

sudo rpm --import https://artifacts.elastic.co/GPG-KEY-elasticsearch

cd /etc/yum.repos.d/

sudo vi elasticsearch.repo

[elasticsearch]
name=Elasticsearch repository for 8.x packages
baseurl=https://artifacts.elastic.co/packages/8.x/yum
gpgcheck=1
gpgkey=https://artifacts.elastic.co/GPG-KEY-elasticsearch
enabled=0
autorefresh=1
type=rpm-md


sudo yum install --enablerepo=elasticsearch elasticsearch


# Configure Elasticsearch and Disable Security. V8 comes with security enabled

sudo nano /etc/elasticsearch/elasticsearch.yml


node.name:  node-1


network.host: 0.0.0.0

discovery.seed.hosts: ["127.0.0.1"]

xpack.security.enabled: false

cluster.initial_master_nodes: ["node-1"]


# Increase default timeout for Elasticsearch start operation. Running Elasticsearch can be slow on your laptop. 

sudo nano /lib/systemd/system/elasticsearch.service

TimeoutStartSec=600

# Open another session and give permissions to read elasticsearch logs

sudo chmod 755 -R /var/log/elasticsearch/

# Configure Elasticsearch to start automatically when the system boots up
sudo /bin/systemctl daemon-reload
sudo /bin/systemctl enable elasticsearch.service

# Elasticsearch can be started as follows
sudo /bin/systemctl start elasticsearch.service
sudo /bin/systemctl status elasticsearch.service


# Check that Elasticsearch is running
curl -XGET 127.0.0.1:9200


# Download mapping for index
sudo wget http://media.sundog-soft.com/es8/shakes-mapping.json
curl -H "Content-Type: application/json" -XPUT 127.0.0.1:9200/shakespeare --data-binary @shakes-mapping.json
{
        "mappings" : {
                "properties" : {
                        "speaker" : {"type": "keyword" },
                        "play_name" : {"type": "keyword" },
                        "line_id" : { "type" : "integer" },
                        "speech_number" : { "type" : "integer" }
                }
        }
}



# Download shakespeare data
sudo wget http://media.sundog-soft.com/es8/shakespeare_8.0.json



# Index data to Elasticsearch
curl -H "Content-Type: application/json" -XPUT '127.0.0.1:9200/shakespeare/_bulk' --data-binary @shakespeare_8.0.json


# Try searching a phrase

curl -H "Content-Type: application/json" -XGET '127.0.0.1:9200/shakespeare/_search?pretty' -d '
{
"query" : {
"match_phrase" : {
"text_entry" : "to be or not to be"
}
}
}' 