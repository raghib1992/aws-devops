#!/bin/bash
aws s3 cp s3://code-build-demo-project/demo-build-project/my-app /tmp/
