#!/bin/bash
aws s3 cp s3://raghib-db-backup-1/artifacts/my-app /tmp/
